package com.android.tests.flavors.group2;

public class SomeClass {
    public static String getString() {
        return "fa";
    }
}