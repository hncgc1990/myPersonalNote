package com.android.tests.dependencies;

public interface BuildType {
    String getBuildType();
}
