package com.android.tests.basic;

public class StringProvider {

    public static String getString(int foo) {
        return Integer.toString(foo);
    }
}
