package com.android.tests.basic;

public class StringProvider {

    public String getString(int foo) {
        return Integer.toString(foo);
    }
}
